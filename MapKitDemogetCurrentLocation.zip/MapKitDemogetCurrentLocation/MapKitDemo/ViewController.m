//
//  ViewController.m
//  MapKitDemo
//
//  Created by Yinchuan Zhou on 4/21/16.
//  Copyright © 2016 Yinchuan Zhou. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

- (IBAction)CurrentLocation:(UIButton *)sender;
@property(nonatomic,strong) CLGeocoder *geocoder;
@property(nonatomic,strong) CLLocationManager *locationManager;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)CurrentLocation:(UIButton *)sender {
    
    _locationManager = [[CLLocationManager alloc]init];
    _locationManager.delegate = self;
    _locationManager .desiredAccuracy = kCLLocationAccuracyBest;
    [_locationManager requestAlwaysAuthorization];   // IOS 8.0
    [_locationManager requestWhenInUseAuthorization];  // IOS 8.0
    [_locationManager startUpdatingLocation];

}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    CLLocation *Currentlocation = [locations lastObject];
    if (Currentlocation!=nil) {
        [_locationManager stopUpdatingLocation];
        
        NSLog(@"Lat:%f, Long:%f",Currentlocation.coordinate.latitude,Currentlocation.coordinate.longitude);
         _geocoder = [[CLGeocoder alloc] init];
        [_geocoder reverseGeocodeLocation:Currentlocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            if (!error) {
                CLPlacemark *placeMark = [placemarks lastObject];
                NSLog(@"Place Marks: %@",placeMark);
                NSDictionary *location = [placeMark.addressDictionary valueForKey:@"FormattedAddressLines"];
                NSLog(@"%@",location);
            }
        }];
    }
    
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
@end
